// Stripe routes placeholder
