// ListingDetail placeholder
