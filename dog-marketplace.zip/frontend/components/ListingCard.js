// ListingCard placeholder
